﻿using JetBrains.Annotations;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FarmersDelight.Classes.Measurements;
using FarmersDelight.Classes.Farms;
using FarmersDelight.Classes.FarmBuilding;
using FarmersDelight.Classes.Sensors;
using FarmersDelight.Classes.Feed;
using FarmersDelight.Classes.Animal;
using FarmersDelight.Classes.Schedule;

namespace FarmersDelight.Models
{
    public class FarmContext : DbContext
    {
        public FarmContext() : base()
        {
        }

        public FarmContext(DbContextOptions<FarmContext> options) : base(options)
        {

        }
        
        //dbsets
        public DbSet<Pig> pigs { get; set; }
        public DbSet<PigType> pigtypes { get; set; }
        public DbSet<TagType> tagtypes { get; set; }
        public DbSet<Building> buildings { get; set; }
        public DbSet<Pen> pens { get; set; }
        public DbSet<Silo> silos { get; set; }
        public DbSet<Stable> stables { get; set; }
        public DbSet<Address> addresses { get; set; }
        public DbSet<City> citys { get; set; }
        public DbSet<Country> countrys { get; set; }
        public DbSet<Farm> farms { get; set; }
        public DbSet<FeedBlend> feedblends { get; set; }
        public DbSet<FeedDistribution> feeddistributions { get; set; }
        public DbSet<FeedType> feedtypes { get; set; }
        public DbSet<Measurement> measurements { get; set; }
        public DbSet<DataCollectionSchedule> datacollectionschedules { get; set; }
        public DbSet<ScheduleElement> scheduleelements { get; set; }
        public DbSet<Sensor> sensors { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //populate type tables with enum data from our enums/classes
            modelBuilder.Entity<PigType>().HasData(PigTypeEnum.Pig, PigTypeEnum.Sow, PigTypeEnum.Boar, PigTypeEnum.Piglet);
            modelBuilder.Entity<TagType>().HasData(TagTypeEnum.Red, TagTypeEnum.Green, TagTypeEnum.Grey);
            modelBuilder.Entity<FeedType>().HasData(FeedTypeEnum.Wheat, FeedTypeEnum.Peas, FeedTypeEnum.Soja, FeedTypeEnum.Barley);

            //set default value for measurement table
            modelBuilder
                .Entity<Measurement>()
                .Property(b => b.TimeOfMeasurement)
                .HasDefaultValueSql("getdate()");

            //Generate inherited class tables 
            modelBuilder.Entity<Pen>().ToTable("Pen");
            modelBuilder.Entity<Stable>().ToTable("Stable");
            modelBuilder.Entity<Silo>().ToTable("Silo");

        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
//            optionsBuilder.UseSqlServer(@"Data Source=10.108.146.4;Initial Catalog=FarmersDelight;Integrated Security=SSPI;User id=FD;Password=123Abc");
            optionsBuilder.UseSqlServer(@"Data Source=localhost;Initial Catalog=FarmersDelight;Integrated Security=SSPI;User id=sa;Password=Test");
        }
    }
}