﻿using FarmersDelight.Classes.FarmBuilding;
using FarmersDelight.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace FarmersDelight.Controllers
{
    public class StablesController : ApiController
    {
        //api/Stables
        [Route("Stables/")]
        public Stable[] Get()
        {
            using (var context = new FarmContext()) {
                return context.stables.ToArray();
            }
        }

        //api/Stables?sensorType=Water
        [Route("Stables/{sensorType}")]
        public Stable[] Get(string sensorType)
        {
            using (var context = new FarmContext())
            {
                Stable[] returnedStables = context.stables.ToArray();

                foreach (Stable stable in returnedStables)
                {
                    stable.Measurements = stable.Measurements
                        .Where(m => m.SensorType.Name == sensorType)
                        .ToArray();
                }

                return returnedStables;
            }
        }
    }
}
