﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using FarmersDelight.Classes.FarmBuilding;
using FarmersDelight.Models;
using Microsoft.EntityFrameworkCore;

namespace FarmersDelight.Controllers
{
    public class HomeController : Controller
    {
        //AD Path and domain name variables
        string adPath = "LDAP://url.com";
        string domainName = "url";

        FarmContext context = new FarmContext();

        public ActionResult Index()
        {
            ViewBag.Title = $"{Resources.Lang.Global.Menu_AppName.ToString()} > {Resources.Lang.Global.Menu_Home.ToString()}";

            
            return View();
        }

        //generates a view with the buildings as the data model
        public ActionResult Statistics(string buildingName, string sensorName, int? filterType)
        {
            ViewBag.Title = $"{Resources.Lang.Global.Menu_AppName.ToString()} > {Resources.Lang.Global.Menu_Statistics.ToString()}"; ;
            List<Building> buildings;
            if (buildingName == null)
            {
                buildings = context.buildings.ToList();
            }
            else buildings = context.buildings.Where(b => b.Name.Contains(buildingName)).ToList();
            
            return View(buildings);
        }

        public ActionResult ControlPanel()
        {
            ViewBag.Title = $"{Resources.Lang.Global.Menu_AppName.ToString()} > {Resources.Lang.Global.Menu_ControlPanel.ToString()}"; ;

            return View();
        }

        //changes the current language to the one selected within the main menu
        public ActionResult ChangeLanguage(string languageNotation)
        {
            //track current view

            if (languageNotation != null)
            {
                Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(languageNotation);
                Thread.CurrentThread.CurrentUICulture = new CultureInfo(languageNotation);
            }

            HttpCookie cookie = new HttpCookie("language");
            cookie.Value = languageNotation;
            Response.Cookies.Add(cookie);

            //return tracked view instead
            return View("Index");
        }

        //gets the image corresponding to the selected language of the user
        public string GetCurrentLanguageImage()
        {
            if (Request.Cookies["language"] == null)
            {
                ChangeLanguage(null);
            }
            string imageStr = "";
            switch (Request.Cookies["language"].Value)
            {
                case "en-US":
                    imageStr = "united-states-of-america";
                    break;
                case "da-DK":
                    imageStr = "denmark";
                    break;
                case "de-DE":
                    imageStr = "germany";
                    break;
                default:
                    imageStr = "united-states-of-america";
                    break;
            }

            return Path.Combine("/Resources/Images/svg/countries", imageStr + ".svg");
        }

        //authenticates the user, allowing or denying access
        public bool AuthenticateUser(string username, string passwordHash)
        {
            //username from the entered mail string, or just the username if a mail was not used
            username = username.Split('@')[0];
            //username and domain string for later use
            string domainAndUsername = domainName + @"\" + username;

            //entry to look for
            DirectoryEntry entry =
                new DirectoryEntry(
                    adPath,
                    domainAndUsername,
                    passwordHash);
            try
            {
                //get native info from the entry
                object obj = entry.NativeObject;

                //search AD
                DirectorySearcher search = new DirectorySearcher(entry);

                //filter and load user
                search.Filter = "(SAMAccountName=" + username + ")";
                search.PropertiesToLoad.AddRange(
                    new string[] {
                    "SAMAccountName",
                    "cn",
                    "userAccountControl"
                    });

                //store result data
                SearchResult result = search.FindOne();

                //decide whether to authenticate or deny access
                //if the user is legal, store details for the rest of the session
                if (result == null)
                {
                    return false;
                }
                else {
                    //set values to avoid nulls
                    Session["ADUserID"] = string.Empty;
                    Session["ADUserName"] = string.Empty;
                    Session["ADUserAccountControl"] = string.Empty;

                    //fill in with actual values
                    Session["ADUserID"] = result.Properties["SAMAccountName"][0];
                    Session["ADUserName"] = result.Properties["cn"][0];
                    Session["ADUserAccountControl"] = Convert.ToString(result.Properties["userAccountControl"]);
                }
            }
            catch (Exception)
            {
                return false;

                throw;
            }

            return true;
        }
    }
}
