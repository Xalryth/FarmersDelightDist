﻿using FarmersDelight.Classes.Measurements;
using FarmersDelight.Models;
using System.Linq;
using System.Web.Http;

namespace FarmersDelight.Controllers
{
    public class MeasurementsController : ApiController
    {
        //api/Measurements
        [Route("Measurements/")]
        public Measurement[] Get()
        {
            using (var context = new FarmContext())
            {
                return context.measurements.ToArray();
            }
        }

        //api/Measurements?sensorType=UV
        [Route("Measurements/{sensorType}")]
        public Measurement[] Get(string sensorType)
        {
            using (var context = new FarmContext())
            {
                return context.measurements
                    .Where(m => m.SensorType.Name == sensorType)
                    .ToArray();
            }
        }
    }
}
