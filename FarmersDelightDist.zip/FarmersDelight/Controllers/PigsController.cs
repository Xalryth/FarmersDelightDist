﻿using FarmersDelight.Classes.Animal;
using FarmersDelight.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace FarmersDelight.Controllers
{
    public class PigsController : ApiController
    {
        //api/Pigs
        [Route("Pigs/")]
        public Pig[] Get()
        {
            using (var context = new FarmContext()) {
                return context.pigs
                    .ToArray();
            }
        }

        //api/Pigs
        [Route("Pigs/{ID:int}")]
        public Pig Get(string ID)
        {
            using (var context = new FarmContext())
            {
                return context.pigs
                    .Where(p => p.PigID == ID)
                    .First();
            }
        }
    }
}
