﻿using FarmersDelight.Classes.Schedule;
using FarmersDelight.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace FarmersDelight.Controllers
{
    public class SchedulesController : ApiController
    {
        //api/Schedules
        [Route("Schedules/")]
        public DataCollectionSchedule[] Get()
        {
            using (var context = new FarmContext()) {
                return context.datacollectionschedules
                    .ToArray();
            }
        }
    }
}
