﻿using FarmersDelight.Classes.FarmBuilding;
using FarmersDelight.Models;
using System.Linq;
using System.Web.Http;

namespace FarmersDelight.Controllers
{
    public class PensController : ApiController
    {
        //api/Pens
        [Route("Pens")]
        public Pen[] Get()
        {
            using (var context = new FarmContext())
            {
                return context.pens.ToArray();
            }
        }

        //api/Pens?type=UV&pigSearch=false
        [Route("Pens/{type}&{pigSearch:bool}")]
        public Pen[] Get(string type, bool pigSearch)
        {
            using (var context = new FarmContext())
            {
                if (pigSearch)
                {
                    return context.pens
                            .Where(p => p.PigType == context.pigtypes
                                .Where(t => t.Name == type)).ToArray();
                }
                else
                {
                    Pen[] returnedPens = context.pens.ToArray();

                    foreach (Pen pen in returnedPens)
                    {
                        pen.Measurements = pen.Measurements
                                                .Where(s => s.SensorType.Name == type)
                                                .ToArray();
                    }

                    return returnedPens;
                }
            }
        }

        //api/Pens?stype=UV&pType=Piglet
        [Route("Pens/{sType}&{pType}")]
        public Pen[] Get(string sType, string pType)
        {
            using (var context = new FarmContext())
            {
                Pen[] returnedPens = context.pens
                        .Where(p => p.PigType == context.pigtypes
                        .Where(t => t.Name == pType))
                        .ToArray();

                foreach (Pen pen in returnedPens)
                {
                    pen.Measurements = pen.Measurements
                        .Where(m => m.SensorType.Name == sType)
                        .ToArray();
                }

                return returnedPens;
            }
        }
    }
}
