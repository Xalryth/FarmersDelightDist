﻿using FarmersDelight.Classes.FarmBuilding;
using FarmersDelight.Models;
using System.Linq;
using System.Web.Http;

namespace FarmersDelight.Controllers
{
    public class SilosController : ApiController
    {
        //api/Silos
        [Route("Silos/")]
        public Silo[] Get()
        {
            using (var context = new FarmContext())
            {
                return context.silos.ToArray();
            }
        }

        //api/Silos?type=Water&feedSearch=false
        [Route("Silos/{type}&{feedSearch:bool}")]
        public Silo[] Get(string type, bool feedSearch)
        {
            using (var context = new FarmContext())
            {
                if (feedSearch)
                {
                    return context.silos
                        .Where(s => s.FeedType.Name == type)
                        .ToArray();
                }
                else
                {
                    Silo[] returnedSilos = context.silos.ToArray();

                    foreach (Silo silo in returnedSilos)
                    {
                        silo.Measurements = silo.Measurements
                            .Where(m => m.SensorType.Name == type)
                            .ToArray();
                    }

                    return returnedSilos;
                }
            }
        }

        //api/Silos?fType=Soya&sensorType=Water
        [Route("Silos/{fType}&{sensorType}")]
        public Silo[] Get(string fType, string sensorType)
        {
            using (var context = new FarmContext())
            {
                Silo[] returnedSilos = context.silos
                    .Where(s => s.FeedType.Name == fType)
                    .ToArray();

                foreach (Silo silo in returnedSilos)
                {
                    silo.Measurements = silo.Measurements
                        .Where(m => m.SensorType.Name == sensorType)
                        .ToArray();
                }

                return returnedSilos;
            }
        }
    }
}
