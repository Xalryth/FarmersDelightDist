﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace FarmersDelight.Migrations
{
    public partial class initialBuild : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "City",
                columns: table => new
                {
                    Name = table.Column<string>(nullable: true),
                    Zipcode = table.Column<int>(nullable: false),
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_City", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Country",
                columns: table => new
                {
                    Name = table.Column<string>(nullable: true),
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Country", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "FeedType",
                columns: table => new
                {
                    Name = table.Column<string>(maxLength: 64, nullable: false),
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FeedType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PigType",
                columns: table => new
                {
                    Name = table.Column<string>(maxLength: 64, nullable: false),
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PigType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SensorType",
                columns: table => new
                {
                    Name = table.Column<string>(maxLength: 64, nullable: false),
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SensorType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TagType",
                columns: table => new
                {
                    Name = table.Column<string>(maxLength: 64, nullable: false),
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TagType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Address",
                columns: table => new
                {
                    CityId = table.Column<int>(nullable: true),
                    CountryId = table.Column<int>(nullable: true),
                    StreetName = table.Column<string>(nullable: true),
                    StreetNumber = table.Column<int>(nullable: false),
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Address", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Address_City_CityId",
                        column: x => x.CityId,
                        principalTable: "City",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Address_Country_CountryId",
                        column: x => x.CountryId,
                        principalTable: "Country",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Farm",
                columns: table => new
                {
                    Name = table.Column<string>(nullable: true),
                    FarmAddressId = table.Column<int>(nullable: true),
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Farm", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Farm_Address_FarmAddressId",
                        column: x => x.FarmAddressId,
                        principalTable: "Address",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "buildings",
                columns: table => new
                {
                    Name = table.Column<string>(nullable: true),
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Discriminator = table.Column<string>(nullable: false),
                    FarmId = table.Column<int>(nullable: true),
                    PigTypeId = table.Column<int>(nullable: true),
                    StableId = table.Column<int>(nullable: true),
                    FeedTypeId = table.Column<int>(nullable: true),
                    StoredAmount = table.Column<float>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_buildings", x => x.Id);
                    table.ForeignKey(
                        name: "FK_buildings_Farm_FarmId",
                        column: x => x.FarmId,
                        principalTable: "Farm",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_buildings_PigType_PigTypeId",
                        column: x => x.PigTypeId,
                        principalTable: "PigType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_buildings_buildings_StableId",
                        column: x => x.StableId,
                        principalTable: "buildings",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_buildings_FeedType_FeedTypeId",
                        column: x => x.FeedTypeId,
                        principalTable: "FeedType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DataCollectionSchedule",
                columns: table => new
                {
                    Name = table.Column<string>(nullable: true),
                    FramDate = table.Column<DateTime>(nullable: false),
                    ToDate = table.Column<DateTime>(nullable: false),
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FarmId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DataCollectionSchedule", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DataCollectionSchedule_Farm_FarmId",
                        column: x => x.FarmId,
                        principalTable: "Farm",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "FeedBlend",
                columns: table => new
                {
                    Name = table.Column<string>(nullable: true),
                    TargetPigTypeId = table.Column<int>(nullable: true),
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FarmId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FeedBlend", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FeedBlend_Farm_FarmId",
                        column: x => x.FarmId,
                        principalTable: "Farm",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_FeedBlend_PigType_TargetPigTypeId",
                        column: x => x.TargetPigTypeId,
                        principalTable: "PigType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Measurement",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    SensorTypeId = table.Column<int>(nullable: true),
                    TimeOfMeasurement = table.Column<DateTime>(nullable: false, defaultValueSql: "getdate()"),
                    MeasurementValue = table.Column<float>(nullable: false),
                    BuildingId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Measurement", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Measurement_buildings_BuildingId",
                        column: x => x.BuildingId,
                        principalTable: "buildings",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Measurement_SensorType_SensorTypeId",
                        column: x => x.SensorTypeId,
                        principalTable: "SensorType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Pig",
                columns: table => new
                {
                    PigID = table.Column<string>(nullable: false),
                    PigTypeId = table.Column<int>(nullable: true),
                    TagTypeId = table.Column<int>(nullable: true),
                    PenId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Pig", x => x.PigID);
                    table.ForeignKey(
                        name: "FK_Pig_buildings_PenId",
                        column: x => x.PenId,
                        principalTable: "buildings",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Pig_PigType_PigTypeId",
                        column: x => x.PigTypeId,
                        principalTable: "PigType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Pig_TagType_TagTypeId",
                        column: x => x.TagTypeId,
                        principalTable: "TagType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Sensor",
                columns: table => new
                {
                    OwningBuildingId = table.Column<int>(nullable: true),
                    SensorTypeId = table.Column<int>(nullable: true),
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sensor", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Sensor_buildings_OwningBuildingId",
                        column: x => x.OwningBuildingId,
                        principalTable: "buildings",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Sensor_SensorType_SensorTypeId",
                        column: x => x.SensorTypeId,
                        principalTable: "SensorType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "FeedDistribution",
                columns: table => new
                {
                    FeedTypeId = table.Column<int>(nullable: true),
                    PercentageOfBlend = table.Column<float>(nullable: false),
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FeedBlendId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FeedDistribution", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FeedDistribution_FeedBlend_FeedBlendId",
                        column: x => x.FeedBlendId,
                        principalTable: "FeedBlend",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_FeedDistribution_FeedType_FeedTypeId",
                        column: x => x.FeedTypeId,
                        principalTable: "FeedType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ScheduleElement",
                columns: table => new
                {
                    SensorId = table.Column<int>(nullable: true),
                    TriggerTime = table.Column<DateTime>(nullable: false),
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    DataCollectionScheduleId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ScheduleElement", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ScheduleElement_DataCollectionSchedule_DataCollectionScheduleId",
                        column: x => x.DataCollectionScheduleId,
                        principalTable: "DataCollectionSchedule",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ScheduleElement_Sensor_SensorId",
                        column: x => x.SensorId,
                        principalTable: "Sensor",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "FeedType",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 1, "Wheat" },
                    { 3, "Peas" },
                    { 2, "Soja" },
                    { 4, "Barley" }
                });

            migrationBuilder.InsertData(
                table: "PigType",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 1, "Pig" },
                    { 2, "Sow" },
                    { 3, "Boar" },
                    { 4, "Piglet" }
                });

            migrationBuilder.InsertData(
                table: "TagType",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 1, "Red" },
                    { 2, "Green" },
                    { 3, "Grey" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Address_CityId",
                table: "Address",
                column: "CityId");

            migrationBuilder.CreateIndex(
                name: "IX_Address_CountryId",
                table: "Address",
                column: "CountryId");

            migrationBuilder.CreateIndex(
                name: "IX_buildings_FarmId",
                table: "buildings",
                column: "FarmId");

            migrationBuilder.CreateIndex(
                name: "IX_buildings_PigTypeId",
                table: "buildings",
                column: "PigTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_buildings_StableId",
                table: "buildings",
                column: "StableId");

            migrationBuilder.CreateIndex(
                name: "IX_buildings_FeedTypeId",
                table: "buildings",
                column: "FeedTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_DataCollectionSchedule_FarmId",
                table: "DataCollectionSchedule",
                column: "FarmId");

            migrationBuilder.CreateIndex(
                name: "IX_Farm_FarmAddressId",
                table: "Farm",
                column: "FarmAddressId");

            migrationBuilder.CreateIndex(
                name: "IX_FeedBlend_FarmId",
                table: "FeedBlend",
                column: "FarmId");

            migrationBuilder.CreateIndex(
                name: "IX_FeedBlend_TargetPigTypeId",
                table: "FeedBlend",
                column: "TargetPigTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_FeedDistribution_FeedBlendId",
                table: "FeedDistribution",
                column: "FeedBlendId");

            migrationBuilder.CreateIndex(
                name: "IX_FeedDistribution_FeedTypeId",
                table: "FeedDistribution",
                column: "FeedTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Measurement_BuildingId",
                table: "Measurement",
                column: "BuildingId");

            migrationBuilder.CreateIndex(
                name: "IX_Measurement_SensorTypeId",
                table: "Measurement",
                column: "SensorTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Pig_PenId",
                table: "Pig",
                column: "PenId");

            migrationBuilder.CreateIndex(
                name: "IX_Pig_PigTypeId",
                table: "Pig",
                column: "PigTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Pig_TagTypeId",
                table: "Pig",
                column: "TagTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_ScheduleElement_DataCollectionScheduleId",
                table: "ScheduleElement",
                column: "DataCollectionScheduleId");

            migrationBuilder.CreateIndex(
                name: "IX_ScheduleElement_SensorId",
                table: "ScheduleElement",
                column: "SensorId");

            migrationBuilder.CreateIndex(
                name: "IX_Sensor_OwningBuildingId",
                table: "Sensor",
                column: "OwningBuildingId");

            migrationBuilder.CreateIndex(
                name: "IX_Sensor_SensorTypeId",
                table: "Sensor",
                column: "SensorTypeId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "FeedDistribution");

            migrationBuilder.DropTable(
                name: "Measurement");

            migrationBuilder.DropTable(
                name: "Pig");

            migrationBuilder.DropTable(
                name: "ScheduleElement");

            migrationBuilder.DropTable(
                name: "FeedBlend");

            migrationBuilder.DropTable(
                name: "TagType");

            migrationBuilder.DropTable(
                name: "DataCollectionSchedule");

            migrationBuilder.DropTable(
                name: "Sensor");

            migrationBuilder.DropTable(
                name: "buildings");

            migrationBuilder.DropTable(
                name: "SensorType");

            migrationBuilder.DropTable(
                name: "Farm");

            migrationBuilder.DropTable(
                name: "PigType");

            migrationBuilder.DropTable(
                name: "FeedType");

            migrationBuilder.DropTable(
                name: "Address");

            migrationBuilder.DropTable(
                name: "City");

            migrationBuilder.DropTable(
                name: "Country");
        }
    }
}
