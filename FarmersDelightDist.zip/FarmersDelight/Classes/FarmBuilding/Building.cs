﻿using FarmersDelight.Classes.Measurements;
using FarmersDelight.Classes.Sensors;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FarmersDelight.Classes.FarmBuilding
{
    public abstract class Building
    {
        [Key]
        int id;
        [Required]
        [MaxLength(64)]
        string name;
        [ForeignKey("MesurementRefID")]
        ICollection<Measurement> measurements;
        [ForeignKey("SensorRefID")]
        ICollection<Sensor> sensors;


        public string Name { get => name; set => name = value; }
        public ICollection<Measurement> Measurements { get => measurements; set => measurements = value; }
        public ICollection<Sensor> Sensors { get => sensors; set => sensors = value; }
        public int Id { get => id; set => id = value; }

        protected Building(string name)
        {
            Name = name;
        }
    }
}