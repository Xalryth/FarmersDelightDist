﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace FarmersDelight.Classes.FarmBuilding
{
    [Table("Stable")]
    public class Stable : Building
    {
        [ForeignKey("PenRefID")]
        ICollection<Pen> pens;


        public ICollection<Pen> Pens { get => pens; set => pens = value; }

        private Stable(string name) : base(name)
        {
        }
    }
}