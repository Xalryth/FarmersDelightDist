﻿using FarmersDelight.Classes.Feed;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FarmersDelight.Classes.FarmBuilding
{
    [Table("Silo")]
    public class Silo : Building
    {
        [ForeignKey("FeedTypeRefID")]
        FeedType feedType;
        [Required]
        float storedAmount;

        public FeedType FeedType { get => feedType; set => feedType = value; }
        public float StoredAmount { get => storedAmount; set => storedAmount = value; }

        public Silo(string name, FeedType feedType) : base(name)
        {
            FeedType = feedType;
        }
        private Silo(string name) : base(name)
        {
        }
    }
}