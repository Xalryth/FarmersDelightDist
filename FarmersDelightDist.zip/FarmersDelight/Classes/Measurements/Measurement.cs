﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;
using FarmersDelight.Classes.Sensors;
using System.ComponentModel.DataAnnotations;

namespace FarmersDelight.Classes.Measurements
{
    [Table("Measurement")]
    public class Measurement
    {
        [Key]
        int id;
        [ForeignKey("SensorTypeRefid")]
        SensorType sensorType;
        [Required]
        DateTime timeOfMeasurement;
        [Required]
        float measurementValue;

        public int ID { get => id; set=> id = value; }
        public SensorType SensorType { get => sensorType; set => sensorType = value; }
        public DateTime TimeOfMeasurement { get => timeOfMeasurement; set => timeOfMeasurement = value; }
        public float MeasurementValue { get => measurementValue; set => measurementValue = value; }

        private Measurement()
        {
        }
        public Measurement(SensorType sensorType, float measurementValue)
        {
            SensorType = sensorType;
            MeasurementValue = measurementValue;
        }
    }
}