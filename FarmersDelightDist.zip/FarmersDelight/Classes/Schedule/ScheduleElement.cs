﻿using FarmersDelight.Classes.Sensors;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FarmersDelight.Classes.Schedule
{
    [Table("ScheduleElement")]
    public class ScheduleElement
    {
        [Key]
        int id;
        [ForeignKey("SensorRefid")]
        Sensor sensor;
        [Required]
        DateTime triggerTime;

        public Sensor Sensor { get => sensor; set => sensor = value; }
        public DateTime TriggerTime { get => triggerTime; set => triggerTime = value; }
        public int Id { get => id; set => id = value; }

        private ScheduleElement()
        {
        }
        public ScheduleElement(Sensor sensor, DateTime triggerTime)
        {
            Sensor = sensor;
            TriggerTime = triggerTime;
        }
    }
}