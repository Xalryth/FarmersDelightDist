﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FarmersDelight.Classes.Schedule
{
    [Table("DataCollectionSchedule")]
    public class DataCollectionSchedule
    {
        [Key]
        int id;
        [Required]
        [MaxLength(64)]
        string name;
        [ForeignKey("ScheduleElementRefid")]
        ICollection<ScheduleElement> scheduleElements;
        [Required]
        DateTime framDate;
        [Required]
        DateTime toDate;

        public string Name { get => name; set => name = value; }
        public ICollection<ScheduleElement> ScheduleElements { get => scheduleElements; set => scheduleElements = value; }
        public DateTime FramDate { get => framDate; set => framDate = value; }
        public DateTime ToDate { get => toDate; set => toDate = value; }
        public int Id { get => id; set => id = value; }

        private DataCollectionSchedule()
        {
        }
        public DataCollectionSchedule(string name, DateTime framDate, DateTime toDate)
        {
            Name = name;
            FramDate = framDate;
            ToDate = toDate;
        }
    }
}