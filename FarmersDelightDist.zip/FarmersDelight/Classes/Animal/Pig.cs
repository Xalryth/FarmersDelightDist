﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FarmersDelight.Classes.Animal
{
    [Table("Pig")]
    public class Pig
    {
        string pigID;
        [Required]
        [ForeignKey("PigTypeRefId")]
        PigType pigType;
        [Required]
        [ForeignKey("TagTypeRefId")]
        TagType tagType;

        public string PigID { get => PigID; set => PigID = value; }
        public PigType PigType { get => pigType; set => pigType = value; }
        public TagType TagType { get => tagType; set => tagType = value; }
        
        private Pig() { }

        public Pig(string pigID, PigType pigType, TagType tagType)
        {
            PigID = pigID;
            PigType = pigType;
            TagType = tagType;
        }
    }
}