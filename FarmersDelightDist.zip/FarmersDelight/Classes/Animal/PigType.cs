﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FarmersDelight.Classes.Animal
{
    [Table("PigType")]
    public class PigType
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        private int id;

        [Required]
        [MaxLength(64)]
        public string Name { get; set; }
        public int Id { get => id; set => id = value; }

        private PigType(PigTypeEnum type)
        {
            Id = (byte)type;
            Name = type.ToString();
        }
        private PigType()
        {
        }

        public static implicit operator PigType(PigTypeEnum type) => new PigType(type);
        public static implicit operator PigTypeEnum(PigType type) => (PigTypeEnum)type.Id;
    }

    public enum PigTypeEnum : byte
    {
        Pig = 1,
        Sow = 2,
        Boar = 3,
        Piglet = 4
    }
}