﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FarmersDelight.Classes.Animal
{
    [Table("TagType")]
    public class TagType
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        private int id;

        [Required]
        [MaxLength(64)]
        public string Name { get; set; }
        public int Id { get => id; set => id = value; }

        private TagType(TagTypeEnum type)
        {
            Id = (byte)type;
            Name = type.ToString();
        }
        private TagType()
        {
        }

        public static implicit operator TagType(TagTypeEnum type) => new TagType(type);
        public static implicit operator TagTypeEnum(TagType type) => (TagTypeEnum)type.Id;
    }

    public enum TagTypeEnum : byte
    {
        Red = 1,
        Green = 2,
        Grey = 3
    }
}