﻿using FarmersDelight.Classes.FarmBuilding;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FarmersDelight.Classes.Sensors
{
    [Table("Sensor")]
    public class Sensor
    {
        [Key]
        int id;
        [ForeignKey("BuildingRedid")]
        Building owningBuilding;
        [ForeignKey("SensorTypeRedid")]
        SensorType sensorType;

        public Building OwningBuilding { get => owningBuilding; set => owningBuilding = value; }
        public SensorType SensorType { get => sensorType; set => sensorType = value; }
        public int Id { get => id; set => id = value; }

        private Sensor()
        {
        }
        public Sensor(Building owningBuilding, SensorType sensorType)
        {
            OwningBuilding = owningBuilding;
            SensorType = sensorType;
        }
    }
}