﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FarmersDelight.Classes.Feed
{
    [Table("FeedDistribution")]
    public class FeedDistribution
    {
        [Key]
        int id;
        [ForeignKey("FeedTypeRefID")]
        FeedType feedType;
        [Required]
        float percentageOfBlend;


        public FeedType FeedType { get => feedType; set => feedType = value; }
        public float PercentageOfBlend { get => percentageOfBlend; set => percentageOfBlend = value; }
        public int Id { get => id; set => id = value; }

        public FeedDistribution(FeedType feedType, float percentageOfBlend)
        {
            FeedType = feedType;
            PercentageOfBlend = percentageOfBlend;
        }
        public FeedDistribution(float percentageOfBlend)
        {
            PercentageOfBlend = percentageOfBlend;
        }
    }
}