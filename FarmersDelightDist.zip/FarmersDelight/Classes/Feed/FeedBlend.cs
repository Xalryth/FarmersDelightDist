﻿using FarmersDelight.Classes.Animal;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FarmersDelight.Classes.Feed
{
    [Table("FeedBlend")]
    public class FeedBlend
    {
        [Key]
        int id;
        [Required]
        [MaxLength(64)]
        string name;
        [ForeignKey("FeedDistributionRefID")]
        ICollection<FeedDistribution> feedDistributions;
        [ForeignKey("TergetPigTypeRefID")]
        PigType targetPigType;

        public string Name { get => name; set => name = value; }
        public ICollection<FeedDistribution> FeedDistributions { get => feedDistributions; set => feedDistributions = value; }
        public PigType TargetPigType { get => targetPigType; set => targetPigType = value; }
        public int Id { get => id; set => id = value; }

        private FeedBlend(string name)
        {
            Name = name;
        }
        public FeedBlend(string name, PigType targetPigType)
        {
            Name = name;
            TargetPigType = targetPigType;
        }
    }
}