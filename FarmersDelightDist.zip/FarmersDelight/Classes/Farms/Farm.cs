﻿using FarmersDelight.Classes.FarmBuilding;
using FarmersDelight.Classes.Feed;
using FarmersDelight.Classes.Schedule;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FarmersDelight.Classes.Farms
{
    [Table("Farm")]
    public class Farm
    {
        [Key]
        int id;
        [Required]
        [MaxLength(64)]
        string name;
        [ForeignKey("AddressRefId")]
        Address farmAddress;
        [ForeignKey("FeedBlendRefId")]
        ICollection<FeedBlend> feedBlends;
        [ForeignKey("BuildingRefid")]
        ICollection<Building> buildings;
        [ForeignKey("DataCollectionScheduleRefId")]
        ICollection<DataCollectionSchedule> dataCollectionSchedules;
        
        public string Name { get => name; set => name = value; }
        public Address FarmAddress { get => farmAddress; set => farmAddress = value; }
        public virtual ICollection<FeedBlend> FeedBlends { get => feedBlends; set => feedBlends = value; }
        public virtual ICollection<DataCollectionSchedule> DataCollectionSchedules { get => dataCollectionSchedules; set => dataCollectionSchedules = value; }
        public int Id { get => id; set => id = value; }
        public ICollection<Building> Buildings { get => buildings; set => buildings = value; }

        private Farm(string name)
        {
            Name = name;
        }
        public Farm(string name, Address farmAddress)
        {
            Name = name;
            FarmAddress = farmAddress;
        }
    }
}