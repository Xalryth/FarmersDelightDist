﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace FarmersDelight.Classes.Farms
{
    [Table("City")]
    public class City
    {
        [Key]
        int id;
        [Required]
        [MaxLength(64)]
        string name;
        [Required]
        int zipcode;

        public string Name { get => name; set => name = value; }
        public int Zipcode { get => zipcode; set => zipcode = value; }
        public int Id { get => id; set => id = value; }

        private City() { }
        public City(string name, int zipcode)
        {
            Name = name;
            Zipcode = zipcode;
        }
    }
}