﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FarmersDelight.Classes.Farms
{
    [Table("Country")]
    public class Country
    {
        [Key]
        int id;
        [Required]
        [MaxLength(64)]
        string name;

        public string Name { get => name; set => name = value; }
        public int Id { get => id; set => id = value; }

        public Country(string name)
        {
            Name = name;
        }
    }
}